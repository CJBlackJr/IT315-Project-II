//This App is developed as an educational project. Certain materials are included under the fair use exemption of the U.S. Copytight Law and have been prepared according to the multimedia fair use guidelines and are restricted from further use.
//This app is meant for gamers who need some game recommendations. A lot of great games have come out this year so it can be hard to choose which to spend your hard earned cash on.
//Images included in this project are freeware and were obtained from Adobe Stock. I included all freeware images, rather than actual screenshots / art from the games I mention.
//NOTE: I am using Mac in the Cloud so I can't test my sound file...

//  ViewController.swift
//  VideosGameApp
//
//  Created by user247332 on 10/11/23.
//

import UIKit
import AVKit
import AVFoundation

class ViewController: UIViewController {
    
    var SplitViewVG = Game()
    
    @IBOutlet weak var lblgamename: UILabel!
    
    @IBOutlet weak var lblgenre: UILabel!
    
    @IBOutlet weak var lblreleasedate: UILabel!
    
    @IBOutlet weak var lblprice: UILabel!
    
    @IBOutlet weak var lblplatform: UILabel!
    
    @IBOutlet weak var lblgamelength: UILabel!
    
    @IBOutlet weak var txtgamedescription: UITextView!
    
    @IBOutlet weak var imggame: UIImageView!
    
    @IBOutlet weak var swfavgame: UISwitch!
    
    @IBAction func swfavgamevalchange(_ sender: Any) {
        if(swfavgame.isOn) {
            UserDefaults.standard.set(lblgamename.text, forKey: "favorite")
        }
        else{
            UserDefaults.standard.set("", forKey: "favorite")
        }
        
    }
    
    
    @IBAction func btnnextgame(_ sender: Any) {
        setLabels()
    }
    
    @IBAction func btnreviews(_ sender: Any) {
        pop.play()
        let browserApp = UIApplication.shared
        let url = URL(string: randomgame.reviews)
        browserApp.open(url!)
    }
    
  
    var pop: AVAudioPlayer!
    var GameArray = [Game]()
    var randomgame = Game()
    
    func setLabels(){
        var randomgame = SplitViewVG
        lblgamename.text = randomgame.gamename
        lblgenre.text = randomgame.genre
        lblreleasedate.text = randomgame.releasedate
        lblprice.text = randomgame.price
        lblplatform.text = randomgame.platform
        lblgamelength.text = randomgame.gamelength
        txtgamedescription.text = randomgame.gamedescription
        
        let fav = UserDefaults.standard.string(forKey: "favorite")
        swfavgame.isOn = (randomgame.gamename == fav)
        
        txtgamedescription.layer.cornerRadius = 15
        txtgamedescription.layer.borderColor = UIColor.darkGray.cgColor
        txtgamedescription.layer.borderWidth = 3
        
        imggame.image = convertToImage(urlString: randomgame.gameimage)
        //imggame.image = UIImage(named: randomgame.gameimage)
        imggame.layer.cornerRadius = 15
        imggame.layer.borderColor = UIColor.darkGray.cgColor
        imggame.layer.borderWidth = 3
        imggame.contentMode = .scaleAspectFill
        
        pop.play()
        
    }
    
    func convertToImage(urlString: String) -> UIImage {
        let imgURL = URL(string:urlString)!
        let imgData = try? Data(contentsOf: imgURL)
        print(imgData ?? "Error. This image isn't around with this URL... \(imgURL)")
        let img = UIImage(data: imgData!)
        return img!
    }
    
    override func motionBegan(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        lblgamename.alpha = 0
        imggame.alpha = 0
        lblprice.alpha = 0
        lblreleasedate.alpha = 0
        lblplatform.alpha = 0
        txtgamedescription.alpha = 0
        lblgamelength.alpha = 0
        lblgenre.alpha = 0
    }
    
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        UIView.animate(withDuration: 3, animations: {
            self.lblgamename.alpha = 1
            self.imggame.alpha = 1
            self.lblprice.alpha = 1
            self.lblreleasedate.alpha = 1
            self.lblplatform.alpha = 1
            self.txtgamedescription.alpha = 1
            self.lblgamelength.alpha = 1
            self.lblgenre.alpha = 1
        })
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destinationController = segue.destination as! WebViewController
        destinationController.PassedGame = SplitViewVG
    }
        
    override func viewDidLoad() {
        super.viewDidLoad()
        let soundUrl = URL(fileURLWithPath: Bundle.main.path(forResource:"pop", ofType:"mp3")!)
        pop = try?AVAudioPlayer(contentsOf: soundUrl)
        setLabels()
        // Do any additional setup after loading the view.
    }


}

