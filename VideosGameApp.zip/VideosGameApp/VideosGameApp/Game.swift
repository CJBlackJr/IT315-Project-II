//
//  Game.swift
//  VideosGameApp
//
//  Created by user247332 on 10/14/23.
//
import UIKit
import Foundation
class Game {
    var gamename = ""
    var genre = ""
    var releasedate = ""
    var price = ""
    var platform = ""
    var gamelength = ""
    var gamedescription = ""
    var gameimage = ""
    var reviews = ""
    
    
    
    
}
