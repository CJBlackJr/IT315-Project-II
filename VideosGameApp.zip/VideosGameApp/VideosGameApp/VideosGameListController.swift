//
//  VideosGameListController.swift
//  VideosGameApp
//
//  Created by user247332 on 11/30/23.
//

import Foundation
import UIKit

class VideosGameListController : UITableViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        GetJSONData()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        var destController = segue.destination as! ViewController
        let index = tableView.indexPathForSelectedRow
        let selectedRowVG = GameArray[index!.row]
        destController.SplitViewVG = selectedRowVG
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return GameArray.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var myCell = tableView.dequeueReusableCell(withIdentifier: "myCellID")
        var cellIndex = indexPath.row
        var VG = GameArray[cellIndex]
        myCell?.textLabel!.text = VG.gamename
        myCell!.detailTextLabel!.text = "Price: \(VG.price)   Platform: \(VG.platform)"
        
        
        var img:UIImage = convertToImage(urlString: VG.gameimage)
        myCell!.imageView?.image = img
        
        myCell!.imageView?.contentMode = UIView.ContentMode.scaleAspectFill
        myCell!.imageView?.frame.size.width = 175
        myCell!.imageView?.frame.size.height = 175
        myCell!.imageView?.layer.cornerRadius = 28
        myCell!.imageView?.clipsToBounds = true
        myCell!.imageView?.layer.borderWidth = 1
        myCell!.imageView?.layer.borderColor = UIColor.yellow.cgColor
        
        myCell!.textLabel!.font = UIFont.boldSystemFont(ofSize: 18)
        myCell!.textLabel!.textColor = UIColor.blue
        return myCell!
    }
    
    //adding an image to each game listing with the function below
    func convertToImage(urlString: String) -> UIImage {
        let imgURL = URL(string:urlString)!
        let imgData = try? Data(contentsOf: imgURL)
        print(imgData ?? "Error. This image isn't around with this URL... \(imgURL)")
        let img = UIImage(data: imgData!)
        return img!
    }
    
    var GameArray = [Game]()
    
    func GetJSONData(){
        let endPointString = "https://raw.githubusercontent.com/CJBlackJr/IT315-Project-II/main/Games.json"
        let endPointURL = URL(string: endPointString)
        let dataBytes = try? Data(contentsOf:endPointURL!)
        print(dataBytes)
        
        if (dataBytes != nil) {
            let dictionary:NSDictionary = (try!JSONSerialization.jsonObject(with: dataBytes!, options:JSONSerialization.ReadingOptions.mutableContainers)) as! NSDictionary
            print("Dictionary --: \(dictionary) ---- \n")
            let vgDictionary = dictionary["Games"]! as! [[String:AnyObject]]
            for index in 0...vgDictionary.count - 1 {
                let singleVG = vgDictionary[index]
                let vg = Game()
                vg.gamename = singleVG["gamename"] as! String
                vg.genre = singleVG["genre"] as! String
                vg.releasedate = singleVG["releasedate"] as! String
                vg.price = singleVG["price"] as! String
                vg.platform = singleVG["platform"] as! String
                vg.gamelength = singleVG["gamelength"] as! String
                vg.reviews = singleVG["reviews"] as! String
                vg.gamedescription = singleVG["gamedescription"] as! String
                vg.gameimage = singleVG["gameimage"] as! String
                GameArray.append(vg)
            }
        }
    }
    
}
