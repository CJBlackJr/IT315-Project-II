//
//  WebViewController.swift
//  VideosGameApp
//
//  Created by user247332 on 11/30/23.
//

import Foundation
import WebKit

class WebViewController : UIViewController {
    
    
    @IBOutlet weak var WVSite: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let siteURL = URL(string: PassedGame.reviews)
        let request = URLRequest(url:siteURL!)
        WVSite.load(request)
    }
    
    var PassedGame = Game()
}
